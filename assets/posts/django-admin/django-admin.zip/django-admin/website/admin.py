from django.contrib import admin
from website.models import Post, Comentario

# Register your models here.
class PostAdmin(admin.ModelAdmin):
    list_display = ('titulo', 'conteudo', 'data_publicacao')
    ordering = ('-data_publicacao', )
    search_fields = ('titulo', 'conteudo')
    list_filter = ('data_publicacao', )


class ComentarioAdmin(admin.ModelAdmin):
    pass


admin.site.register(Post, PostAdmin)
admin.site.register(Comentario, ComentarioAdmin)

